import '@fontsource-variable/rubik';
